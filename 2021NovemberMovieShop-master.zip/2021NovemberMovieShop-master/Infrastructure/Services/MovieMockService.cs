﻿using ApplicationCore.Contracts.Services;
using ApplicationCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class MovieMockService : IMovieService
    {
       public List<MovieCardResponseModel> GetTop30GrossingMovies()
        {
            var movies = new List<MovieCardResponseModel>()
          {
         new MovieCardResponseModel() {Id=1, Title="Inception", Posterurl="https://img.reelgood.com/content/movie/2208ea58-f84f-48ed-b387-13dd836dc446/poster-780.jpg"},
          new MovieCardResponseModel() { Id = 2, Title = "Intersteller", Posterurl = "http://orig12.deviantart.net/ba26/f/2014/213/3/b/interstellar__2014____poster___2_by_camw1n-d7t74io.png" },
        new MovieCardResponseModel() { Id = 3, Title = "the Dark Knight", Posterurl = "https://fanart.tv/fanart/movies/155/movieposter/the-dark-knight-5d7ed1fd0e76b.jpg" }

        };
            return movies;
        }
    }
}
